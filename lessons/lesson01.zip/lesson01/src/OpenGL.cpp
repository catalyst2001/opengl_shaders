#include "OpenGL.h"

GLenum g_OpenGLError = GL_NO_ERROR;
