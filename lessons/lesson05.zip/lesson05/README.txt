Существуют два варианта сборки урока:
	1. Используя MinGW - используйте Makefile, сборка командой make
	2. Используя Microsoft Visual Studio C++ - используйте проект lesson.vcproj
